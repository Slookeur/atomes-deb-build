/* This file is part of the 'atomes' software

'atomes' is free software: you can redistribute it and/or modify it under the terms
of the GNU Affero General Public License as published by the Free Software Foundation,
either version 3 of the License, or (at your option) any later version.

'atomes' is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with 'atomes'.
If not, see <https://www.gnu.org/licenses/>

Copyright (C) 2022-2026 by CNRS and University of Strasbourg */

/*!
* @file update_p.c
* @short Functions to update a project \n
         Functions to activate a project
* @author Sébastien Le Roux <sebastien.leroux@ipcms.unistra.fr>
*/

/*
* This file: 'update_p.c'
*
* Contains:
*

 - The functions to update a project
 - The functions to activate a project

*
* List of functions:

  int update_project ();

  void prep_calc_actions ();
  void active_project_changed (int id);
  void opengl_project_changed (int id);
  void update_analysis_availability (project * this_proj);

*/

#include "global.h"
#include "bind.h"
#include "interface.h"
#include "callbacks.h"
#include "project.h"
#include "workspace.h"

extern GtkWidget * work_menu (int p, int c);
extern GtkTreeStore * tool_model;

/*!
  \fn void prep_calc_actions ()

  \brief prepare analysis widgets
*/
void prep_calc_actions ()
{
  int i;
  gchar * str;
  // Depends on the number of calculations available
  for (i=0; i<NCALCS-1; i++)
  {
    str = g_strdup_printf ("analyze.%d", i);
    if (! active_project || ! active_project -> analysis)
    {
      remove_action (str);
    }
    else
    {
      if (i < ANG)
      {
        if (active_project -> analysis[i])
        {
          if (active_project -> analysis[i] -> avail_ok)
          {
            add_analysis_action (i);
          }
          else
          {
            remove_action (str);
          }
        }
        else
        {
          remove_action (str);
        }
      }
      else
      {
        if (active_project -> analysis[i+1])
        {
          if (active_project -> analysis[i+1] -> avail_ok)
          {
            add_analysis_action (i);
          }
          else
          {
            remove_action (str);
          }
        }
        else
        {
          remove_action (str);
        }
      }
    }
    g_free (str);
  }
}

/*!
  \fn void update_analysis_availability (project * this_proj)

  \brief update analysis availability for a target projet

  \param this_proj the target project
*/
void update_analysis_availability (project * this_proj)
{
  if (this_proj -> natomes && this_proj -> analysis)
  {
    if (this_proj -> cell.has_a_box)
    {
      if (this_proj -> analysis[GDR]) this_proj -> analysis[GDR] -> avail_ok = TRUE;
      if (this_proj -> analysis[SKD]) this_proj -> analysis[SKD] -> avail_ok = TRUE;
      if (this_proj -> analysis[SQD] && this_proj -> analysis[GDR]) this_proj -> analysis[SQD] -> avail_ok = this_proj -> analysis[GDR] -> calc_ok;
      if (this_proj -> analysis[GDK] && this_proj -> analysis[SKD]) this_proj -> analysis[GDK] -> avail_ok = this_proj -> analysis[SKD] -> calc_ok;
      // if (this_proj -> steps > 1 && this_proj -> analysis[SKT]) this_proj -> analysis[SKT] -> avail_ok = TRUE;
    }
    else
    {
      if (this_proj -> analysis[GDR]) this_proj -> analysis[GDR] -> avail_ok = FALSE;
      if (this_proj -> analysis[SQD]) this_proj -> analysis[SQD] -> avail_ok = FALSE;
      if (this_proj -> analysis[SKD]) this_proj -> analysis[SKD] -> avail_ok = FALSE;
      if (this_proj -> analysis[GDK]) this_proj -> analysis[GDK] -> avail_ok = FALSE;
    }
    if (this_proj -> analysis[BND]) this_proj -> analysis[BND] -> avail_ok = TRUE;
    if (this_proj -> analysis[ANG]) this_proj -> analysis[ANG] -> avail_ok = TRUE;
    if (this_proj -> analysis[RIN]) this_proj -> analysis[RIN] -> avail_ok = TRUE;
    if (this_proj -> analysis[CHA]) this_proj -> analysis[CHA] -> avail_ok = TRUE;
    if (this_proj -> analysis[SPH]) this_proj -> analysis[SPH] -> avail_ok = TRUE;
    if (this_proj -> steps > 1 && this_proj -> analysis[MSD]) this_proj -> analysis[MSD] -> avail_ok = TRUE;
  }
  else if (this_proj -> analysis)
  {
    int i;
    for (i=0; i<NCALCS; i++)
    {
      if (this_proj -> analysis[i]) this_proj -> analysis[i] -> avail_ok = FALSE;
    }
  }
}

/*!
  \fn int update_project ()

  \brief update project: send data to Fortran90, and update calculation interactors
*/
int update_project ()
{
#ifdef DEBUG
  g_debug ("UPDATE_PROJECT: to update");
#endif
  int i, j;
  if (! active_project -> newproj && active_project -> natomes)
  {
    i = alloc_data_ (& active_project -> natomes,
                     & active_project -> nspec,
                     & active_project -> steps);
    if (i == 1)
    {
      to_read_pos ();
      int * lot = allocint (active_project -> natomes);
      for (j=0; j<active_project -> natomes; j++) lot[j] = active_project -> atoms[0][j].sp;
      read_data_ (lot, active_chem -> nsps);
      g_free (lot);
      read_chem_ (active_chem -> chem_prop[CHEM_M], active_chem -> chem_prop[CHEM_R],
                  active_chem -> chem_prop[CHEM_N], active_chem -> chem_prop[CHEM_X]);
      j = 0;
      prep_spec_ (active_chem -> chem_prop[CHEM_Z], active_chem -> nsps, & j);
    }
    else
    {
      return 0;
    }
    if (active_project -> run)
    {
      j = (active_cell -> npt) ? active_project -> steps : 1;
      for (i=0; i<j; i++)
      {
        lattice_ (& j, & i,
                  active_cell -> box[i].vect,
                  active_cell -> box[i].param[0],
                  active_cell -> box[i].param[1],
                  & active_cell -> ltype,
                  & active_cell -> frac,
                  & active_cell -> pbc);

      }
      cutoffsend ();
    }
  }
  if (! atomes_render_image && atomes_convert_file == NONE) update_analysis_availability (active_project);
#ifdef DEBUG
  g_debug ("UPDATE_PROJECT: updated");
#endif
  return 1;
}

/*!
  \fn void active_project_changed (int id)

  \brief change the active project

  \param id the id of the new active project
*/
void active_project_changed (int id)
{
  char * errp = NULL;
  if (! atomes_render_image && atomes_convert_file == NONE)
  {
    if (id != inactep && inactep < nprojects && ! atomes_logo) clean_view ();
    gtk_tree_store_clear (tool_model);
  }
  activep = id;
  active_project = get_project_by_id (id);
  active_chem = active_project -> chemistry;
  active_coord = active_project -> coord;
  active_cell = & active_project -> cell;
  active_box = NULL;
  active_glwin = NULL;
  active_image = NULL;
  if (active_project -> modelgl != NULL)
  {
    active_glwin = active_project -> modelgl;
    if (active_glwin -> anim != NULL)
    {
      active_image = active_glwin -> anim -> last -> img;
    }
  }

  if (active_cell -> box)
  {
    if (active_project -> steps == 1 || ! active_cell -> npt || ! active_image)
    {
      active_box = & active_cell -> box[0];
    }
    else if (active_cell -> npt)
    {
      active_box = & active_cell -> box[active_image -> step];
    }
  }
  if (update_project() == 0)
  {
    errp = g_strdup_printf (_("Impossible to update project: %s\n"), active_project -> name);
    show_error (errp, 0, atomes_main_window);
    g_free (errp);
  }
  else
  {
    if (! atomes_render_image && atomes_convert_file == NONE)
    {
      if (active_project -> analysis)
      {
        prep_calc_actions ();
        g_action_map_add_action (G_ACTION_MAP(atomes_app), G_ACTION(edition_actions[0]));
        if (active_cell -> npt)
        {
          remove_action (edition_acts[1].action_name);
        }
        else
        {
          g_action_map_add_action (G_ACTION_MAP(atomes_app), G_ACTION(edition_actions[1]));
        }
        g_action_map_add_action (G_ACTION_MAP(atomes_app), G_ACTION(edition_actions[2]));
        fill_tool_model ();
        correct_this_window_title (curvetoolbox, g_strdup_printf (_("Toolboxes - %s"), prepare_for_title(active_project -> name)));
        correct_this_window_title (atomes_main_window, g_strdup_printf ("%s - %s", PACKAGE, prepare_for_title (active_project -> name)));
      }
    }
    inactep = activep;
  }
  activew = activep;
}

/*!
  \fn void opengl_project_changed (int id)

  \brief change the OpenGL project

  \param id the id of the new OpenGL project
*/
void opengl_project_changed (int id)
{
  activev = id;
  opengl_project = get_project_by_id(id);
}
