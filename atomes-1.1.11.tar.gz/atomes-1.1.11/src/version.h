#define FC "gfortran 12.2.1"
#define FCFLAGS "-fno-second-underscore -O0 -Wall -g3 -pg -ggdb3 -cpp -dA -dD -dH -dp -dP -fvar-tracking -fbounds-check -fstack-protector-all"
#define CC "gcc 12.2.1"
#define CFLAGS "-O0 -Wall -g3 -pg -ggdb3 -cpp -dA -dD -dH -dp -dP -fvar-tracking -fbounds-check -fstack-protector-all"
